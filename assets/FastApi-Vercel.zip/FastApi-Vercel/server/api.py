from fastapi import FastAPI, Body
from pydantic import BaseModel
import ai21

app = FastAPI()

class TextModel(BaseModel):
    input_text: str
    model: str
    min_length: int = 40
    max_length: int = 80
    input_type: str = 'text'

@app.post(f"/get_summary/")
async def receive_long_text(input: TextModel = Body(...)):

    ai21.api_key ="ChzMvcuC0HshLAbbGrBSygCeaNuKVasE"

    summary = 'error'
    res = 'error'
    if(input.input_text == ''):
        return {"output_text": 'Error: Input cannot be empty'}
    if(input.min_length >= input.max_length):
        return {"output_text": 'Error: Max Length must be greater than Min Length'}
    if(input.input_type == 'url'):
        res=ai21.Summarize.execute(source=input.input_text, sourceType="URL")

    if(input.input_type == 'text'):
        res=ai21.Summarize.execute(source=input.input_text, sourceType="TEXT")
    summary = res['summary']
    # print(res)
    # print(res['summary'])

    # if(input.model == 'T5'):
    #     summary = summarizeT5(input.input_text, input.min_length, input.max_length)

    return {"output_text": summary}

